import '../models/expense.dart';

/// Сервис для автоматического определения категории расхода
/// на основе названия магазина/продавца
class CategoryDetector {
  // Ключевые слова для каждой категории
  static const Map<ExpenseCategory, List<String>> _categoryKeywords = {
    ExpenseCategory.food: [
      // Рестораны и кафе
      'макдональдс', 'mcdonalds', 'mcdonald', 'kfc', 'кфс',
      'burger king', 'бургер кинг', 'subway', 'сабвей',
      'starbucks', 'старбакс', 'coffee', 'кофе', 'кофейня',
      'пицца', 'pizza', 'hut', 'domino', 'домино',
      'суши', 'sushi', 'роллы', 'wok', 'вок',
      'ресторан', 'restaurant', 'кафе', 'cafe', 'столовая',
      'бар', 'bar', 'паб', 'pub', 'гриль', 'grill',
      'шаурма', 'шашлык', 'фастфуд', 'fast food',
      'еда', 'food', 'delivery', 'доставка',
      'яндекс еда', 'yandex food', 'delivery club', 'деливери',
      'самокат', 'samokat', 'лавка',
      
      // Продуктовые магазины
      'пятёрочка', 'пятерочка', 'pyaterochka',
      'магнит', 'magnit', 'перекрёсток', 'перекресток',
      'дикси', 'diksi', 'ашан', 'auchan',
      'лента', 'lenta', 'metro', 'метро',
      'окей', 'o\'key', 'вкусвилл', 'vkusvill',
      'азбука вкуса', 'azbuka', 'глобус', 'globus',
      'продукты', 'grocery', 'супермаркет', 'supermarket',
      'мясо', 'meat', 'рыба', 'fish', 'овощи', 'фрукты',
      'пекарня', 'bakery', 'хлеб', 'bread',
      'spar', 'спар', 'билла', 'billa', 'атак',
    ],
    
    ExpenseCategory.transport: [
      'яндекс такси', 'yandex taxi', 'uber', 'убер',
      'ситимобил', 'citymobil', 'такси', 'taxi', 'cab',
      'gett', 'гетт', 'везёт', 'везет',
      'bolt', 'болт', 'maxim', 'максим',
      'метро', 'metro', 'subway', 'подземка',
      'автобус', 'bus', 'троллейбус', 'трамвай',
      'электричка', 'поезд', 'train', 'ржд', 'rzd',
      'аэроэкспресс', 'aeroexpress',
      'каршеринг', 'carsharing', 'делимобиль', 'delimobil',
      'яндекс драйв', 'yandex drive', 'белка', 'belka',
      'ситидрайв', 'citydrive', 'матрёшка',
      'азс', 'gas', 'бензин', 'petrol', 'fuel', 'топливо',
      'лукойл', 'lukoil', 'газпром', 'gazprom', 'роснефть',
      'shell', 'шелл', 'bp', 'татнефть',
      'парковка', 'parking', 'стоянка',
      'самокат', 'scooter', 'велосипед', 'bicycle', 'bike',
      'whoosh', 'вуш', 'юрент', 'urent',
    ],
    
    ExpenseCategory.shopping: [
      'wildberries', 'вайлдберриз', 'wb',
      'ozon', 'озон', 'amazon', 'амазон',
      'aliexpress', 'алиэкспресс', 'али',
      'яндекс маркет', 'yandex market',
      'сбермегамаркет', 'мегамаркет',
      'детский мир', 'детмир',
      'h&m', 'zara', 'зара', 'uniqlo', 'юникло',
      'reserved', 'reserved', 'bershka', 'бершка',
      'pull&bear', 'massimo dutti', 'mango', 'манго',
      'gloria jeans', 'глория джинс', 'ostin', 'остин',
      'спортмастер', 'sportmaster', 'декатлон', 'decathlon',
      'adidas', 'адидас', 'nike', 'найк', 'puma', 'пума',
      'ikea', 'икеа', 'леруа', 'leroy merlin',
      'obi', 'оби', 'castorama', 'касторама',
      'м.видео', 'mvideo', 'эльдорадо', 'eldorado',
      'dns', 'днс', 'ситилинк', 'citilink',
      're:store', 'restore', 'apple', 'эппл', 'samsung',
      'магазин', 'shop', 'store', 'mall', 'тц', 'трц',
      'одежда', 'clothes', 'обувь', 'shoes',
      'товары', 'goods', 'покупка', 'purchase',
    ],
    
    ExpenseCategory.entertainment: [
      'кино', 'cinema', 'movie', 'фильм',
      'каро', 'karo', 'синема', 'imax',
      'theatre', 'театр', 'концерт', 'concert',
      'билет', 'ticket', 'афиша', 'kassir',
      'netflix', 'нетфликс', 'кинопоиск', 'kinopoisk',
      'spotify', 'спотифай', 'apple music',
      'youtube', 'ютуб', 'premium', 'премиум',
      'игра', 'game', 'steam', 'стим', 'playstation', 'xbox',
      'nintendo', 'нинтендо',
      'парк', 'park', 'аттракцион', 'attraction',
      'боулинг', 'bowling', 'бильярд', 'billiard',
      'квест', 'quest', 'escape', 'эскейп',
      'караоке', 'karaoke', 'клуб', 'club', 'бар', 'bar',
      'музей', 'museum', 'выставка', 'exhibition',
      'зоопарк', 'zoo', 'аквапарк', 'aquapark',
      'развлечения', 'entertainment', 'отдых', 'leisure',
    ],
    
    ExpenseCategory.bills: [
      'жкх', 'коммуналка', 'utilities',
      'электричество', 'electricity', 'свет',
      'газ', 'gas', 'вода', 'water',
      'отопление', 'heating', 'тепло',
      'интернет', 'internet', 'wifi', 'вай-фай',
      'ростелеком', 'rostelecom', 'мтс', 'mts',
      'билайн', 'beeline', 'мегафон', 'megafon',
      'теле2', 'tele2', 'yota', 'йота',
      'телефон', 'phone', 'мобильная связь', 'mobile',
      'аренда', 'rent', 'квартплата',
      'ипотека', 'mortgage', 'кредит', 'credit', 'loan',
      'страховка', 'insurance', 'осаго', 'каско',
      'налог', 'tax', 'штраф', 'fine', 'пеня',
      'подписка', 'subscription',
    ],
    
    ExpenseCategory.health: [
      'аптека', 'pharmacy', 'лекарства', 'medicine',
      'аптека 36.6', 'апрель', 'горздрав',
      'ригла', 'rigla', 'самсон', 'samson',
      'столичка', 'stolichka', 'неофарм',
      'врач', 'doctor', 'клиника', 'clinic', 'hospital',
      'медицина', 'medical', 'здоровье', 'health',
      'стоматология', 'dental', 'зуб', 'tooth',
      'анализы', 'analysis', 'lab', 'лаборатория',
      'инвитро', 'invitro', 'гемотест', 'hemotest',
      'медси', 'medsi', 'будь здоров',
      'фитнес', 'fitness', 'gym', 'спортзал', 'тренажёрный',
      'world class', 'x-fit', 'alex fitness',
      'йога', 'yoga', 'пилатес', 'pilates',
      'массаж', 'massage', 'spa', 'спа', 'салон',
      'оптика', 'optic', 'очки', 'glasses', 'линзы',
    ],
    
    ExpenseCategory.education: [
      'курсы', 'courses', 'course',
      'обучение', 'education', 'learning',
      'школа', 'school', 'университет', 'university',
      'институт', 'institute', 'колледж', 'college',
      'книга', 'book', 'учебник', 'textbook',
      'литрес', 'litres', 'книжный', 'bookstore',
      'skillbox', 'скиллбокс', 'нетология', 'netology',
      'geekbrains', 'гикбрейнс', 'яндекс практикум',
      'coursera', 'курсера', 'udemy', 'юдеми',
      'duolingo', 'дуолинго', 'skyeng', 'скаенг',
      'репетитор', 'tutor', 'урок', 'lesson',
      'семинар', 'seminar', 'вебинар', 'webinar',
      'конференция', 'conference',
    ],
    
    ExpenseCategory.travel: [
      'авиа', 'avia', 'flight', 'самолёт', 'airplane',
      'аэрофлот', 'aeroflot', 's7', 'победа', 'pobeda',
      'utair', 'ютейр', 'уральские', 'ural',
      'отель', 'hotel', 'гостиница', 'hostel', 'хостел',
      'booking', 'букинг', 'airbnb', 'эйрбнб',
      'островок', 'ostrovok', '101hotels',
      'тур', 'tour', 'путёвка', 'travel',
      'турагентство', 'travel agency',
      'виза', 'visa', 'паспорт', 'passport',
      'экскурсия', 'excursion', 'guide', 'гид',
      'прокат', 'rental', 'car rental',
      'чемодан', 'luggage', 'багаж',
    ],
    
    ExpenseCategory.transfer: [
      'перевод', 'transfer', 'p2p',
      'сбербанк', 'sberbank', 'сбер', 'sber',
      'тинькофф', 'tinkoff', 'тиньков',
      'альфа', 'alfa', 'alpha',
      'втб', 'vtb', 'райффайзен', 'raiffeisen',
      'газпромбанк', 'gazprombank',
      'банк', 'bank', 'перевод на карту',
      'сбп', 'sbp', 'система быстрых платежей',
    ],
  };

  ExpenseCategory detectCategory(String merchantName) {
    final lowerMerchant = merchantName.toLowerCase();
    
    // Проверяем каждую категорию
    for (final entry in _categoryKeywords.entries) {
      for (final keyword in entry.value) {
        if (lowerMerchant.contains(keyword)) {
          return entry.key;
        }
      }
    }
    
    return ExpenseCategory.other;
  }
  
  /// Получить список ключевых слов для категории
  List<String> getKeywordsForCategory(ExpenseCategory category) {
    return _categoryKeywords[category] ?? [];
  }
  
  /// Добавить пользовательское правило для определения категории
  /// В будущем можно добавить сохранение пользовательских правил
  static final Map<String, ExpenseCategory> _customRules = {};
  
  void addCustomRule(String keyword, ExpenseCategory category) {
    _customRules[keyword.toLowerCase()] = category;
  }
  
  void removeCustomRule(String keyword) {
    _customRules.remove(keyword.toLowerCase());
  }
}
