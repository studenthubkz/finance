import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:flutter_animate/flutter_animate.dart';

import '../providers/settings_provider.dart';
import '../services/notification_service.dart';
import '../theme/app_theme.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final NotificationService _notificationService = NotificationService();
  bool _hasNotificationPermission = false;

  @override
  void initState() {
    super.initState();
    _checkPermission();
  }

  Future<void> _checkPermission() async {
    final hasPermission = await _notificationService.hasPermission();
    setState(() => _hasNotificationPermission = hasPermission);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildHeader(context),
              const SizedBox(height: 24),
              _buildNotificationSection(context),
              const SizedBox(height: 16),
              _buildBudgetSection(context),
              const SizedBox(height: 16),
              _buildCurrencySection(context),
              const SizedBox(height: 16),
              _buildAboutSection(context),
              const SizedBox(height: 80),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildHeader(BuildContext context) {
    return Text(
      'Настройки',
      style: Theme.of(context).textTheme.displaySmall,
    ).animate().fadeIn().slideX(begin: -0.1);
  }

  Widget _buildNotificationSection(BuildContext context) {
    return _buildSection(
      context,
      title: 'Уведомления',
      icon: Icons.notifications_rounded,
      children: [
        _buildPermissionTile(context),
        const Divider(height: 1),
        Consumer<SettingsProvider>(
          builder: (context, settings, _) {
            return _buildSwitchTile(
              context,
              title: 'Отслеживать Google Pay',
              subtitle: 'Автоматически добавлять расходы',
              value: settings.notificationsEnabled,
              onChanged: (value) => settings.setNotificationsEnabled(value),
            );
          },
        ),
      ],
    ).animate().fadeIn(delay: 100.ms);
  }

  Widget _buildPermissionTile(BuildContext context) {
    return ListTile(
      title: const Text('Доступ к уведомлениям'),
      subtitle: Text(
        _hasNotificationPermission ? 'Разрешено' : 'Требуется разрешение',
        style: TextStyle(
          color: _hasNotificationPermission
              ? AppTheme.successColor
              : AppTheme.warningColor,
        ),
      ),
      trailing: _hasNotificationPermission
          ? const Icon(Icons.check_circle_rounded, color: AppTheme.successColor)
          : ElevatedButton(
              onPressed: _requestPermission,
              style: ElevatedButton.styleFrom(
                backgroundColor: AppTheme.primaryColor,
                padding: const EdgeInsets.symmetric(horizontal: 16),
              ),
              child: const Text('Разрешить'),
            ),
    );
  }

  Future<void> _requestPermission() async {
    await _notificationService.requestPermission();
    await _checkPermission();
  }

  Widget _buildBudgetSection(BuildContext context) {
    return Consumer<SettingsProvider>(
      builder: (context, settings, _) {
        return _buildSection(
          context,
          title: 'Бюджет',
          icon: Icons.account_balance_wallet_rounded,
          children: [
            ListTile(
              title: const Text('Месячный бюджет'),
              subtitle: Text(
                settings.monthlyBudget > 0
                    ? settings.formatAmountFull(settings.monthlyBudget)
                    : 'Не установлен',
              ),
              trailing: const Icon(Icons.chevron_right_rounded),
              onTap: () => _showBudgetDialog(context, settings),
            ),
          ],
        );
      },
    ).animate().fadeIn(delay: 200.ms);
  }

  void _showBudgetDialog(BuildContext context, SettingsProvider settings) {
    final controller = TextEditingController(
      text: settings.monthlyBudget > 0
          ? settings.monthlyBudget.toStringAsFixed(0)
          : '',
    );

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Месячный бюджет'),
        content: TextField(
          controller: controller,
          keyboardType: TextInputType.number,
          decoration: const InputDecoration(
            hintText: 'Введите сумму',
            suffixText: '₽',
          ),
          autofocus: true,
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Отмена'),
          ),
          ElevatedButton(
            onPressed: () {
              final amount = double.tryParse(controller.text) ?? 0;
              settings.setMonthlyBudget(amount);
              Navigator.pop(context);
            },
            child: const Text('Сохранить'),
          ),
        ],
      ),
    );
  }

  Widget _buildCurrencySection(BuildContext context) {
    return Consumer<SettingsProvider>(
      builder: (context, settings, _) {
        return _buildSection(
          context,
          title: 'Валюта',
          icon: Icons.currency_exchange_rounded,
          children: [
            ListTile(
              title: const Text('Валюта'),
              subtitle: Text(_getCurrencyName(settings.currency)),
              trailing: const Icon(Icons.chevron_right_rounded),
              onTap: () => _showCurrencyDialog(context, settings),
            ),
          ],
        );
      },
    ).animate().fadeIn(delay: 300.ms);
  }

  String _getCurrencyName(String symbol) {
    switch (symbol) {
      case '₽':
        return 'Российский рубль (₽)';
      case '\$':
        return 'Доллар США (\$)';
      case '€':
        return 'Евро (€)';
      case '£':
        return 'Фунт стерлингов (£)';
      default:
        return symbol;
    }
  }

  void _showCurrencyDialog(BuildContext context, SettingsProvider settings) {
    final currencies = ['₽', '\$', '€', '£'];
    
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Выберите валюту'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: currencies.map((currency) {
            return ListTile(
              title: Text(_getCurrencyName(currency)),
              trailing: settings.currency == currency
                  ? const Icon(Icons.check_rounded, color: AppTheme.primaryColor)
                  : null,
              onTap: () {
                settings.setCurrency(currency);
                Navigator.pop(context);
              },
            );
          }).toList(),
        ),
      ),
    );
  }

  Widget _buildAboutSection(BuildContext context) {
    return _buildSection(
      context,
      title: 'О приложении',
      icon: Icons.info_outline_rounded,
      children: [
        const ListTile(
          title: Text('Версия'),
          subtitle: Text('1.0.0'),
        ),
        const Divider(height: 1),
        ListTile(
          title: const Text('Как это работает'),
          trailing: const Icon(Icons.chevron_right_rounded),
          onTap: () => _showHowItWorksDialog(context),
        ),
      ],
    ).animate().fadeIn(delay: 400.ms);
  }

  void _showHowItWorksDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Как это работает'),
        content: const SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                '1. Разрешите доступ к уведомлениям\n\n'
                '2. Приложение автоматически читает уведомления от Google Pay\n\n'
                '3. Когда вы оплачиваете покупку, расход автоматически добавляется в приложение\n\n'
                '4. Категория определяется автоматически по названию магазина\n\n'
                '5. Дубликаты уведомлений отфильтровываются',
                style: TextStyle(height: 1.5),
              ),
              SizedBox(height: 16),
              Text(
                'Форматы уведомлений Google Pay:',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 8),
              Text(
                '• "₽1 234,56 в Магазин"\n'
                '• "Оплата 1234,56 ₽ в Магазин"\n'
                '• "\$12.34 at Store Name"',
                style: TextStyle(
                  fontFamily: 'monospace',
                  color: AppTheme.textSecondary,
                ),
              ),
            ],
          ),
        ),
        actions: [
          ElevatedButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Понятно'),
          ),
        ],
      ),
    );
  }

  Widget _buildSection(
    BuildContext context, {
    required String title,
    required IconData icon,
    required List<Widget> children,
  }) {
    return Container(
      decoration: BoxDecoration(
        color: AppTheme.cardColor,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                Icon(icon, color: AppTheme.primaryColor, size: 20),
                const SizedBox(width: 8),
                Text(
                  title,
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                        color: AppTheme.primaryColor,
                      ),
                ),
              ],
            ),
          ),
          ...children,
        ],
      ),
    );
  }

  Widget _buildSwitchTile(
    BuildContext context, {
    required String title,
    required String subtitle,
    required bool value,
    required ValueChanged<bool> onChanged,
  }) {
    return SwitchListTile(
      title: Text(title),
      subtitle: Text(subtitle),
      value: value,
      onChanged: onChanged,
    );
  }
}
